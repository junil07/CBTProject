package board;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import project.Board_commentMgr;
import project.UtilMgr;

@WebServlet("/board/deletepostcomment")
public class DeleteServletComment extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Board_commentMgr bMgr = new Board_commentMgr();
		String Dpos = request.getParameter("Dpos");
		String Dref = request.getParameter("Dref");
		String Ddepth = request.getParameter("Ddepth");
		int Dnum = UtilMgr.parseInt(request, "Dnum");
		
		bMgr.deleteComment(Dpos, Dref, Ddepth);
		String redirectURL = "BoardRead.jsp";
		redirectURL += "?num=" + Dnum;
        //지정된 URL로 리다이렉트
        response.sendRedirect(redirectURL);
	}

}
