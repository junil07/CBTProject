package board;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import project.Board_commentBean;
import project.Board_commentMgr;

import project.UtilMgr;

/**
 * Servlet implementation class insertUnderCommetServlet
 */
@WebServlet("/board/insertUnderComment")
public class insertUnderCommetServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Board_commentBean bcbean = new Board_commentBean();
		Board_commentMgr bcmgr = new Board_commentMgr();
		String Cpos = request.getParameter("Cpos");
		String Cref = request.getParameter("Cref");
		String Cdepth = request.getParameter("Cdepth");
		String under_comment = request.getParameter("under_comment");
		String userId = request.getParameter("userId");
		int cnum = UtilMgr.parseInt(request, "num");
		bcmgr.underComment(Cpos, Cref, Cdepth, under_comment, userId, cnum, bcbean);
		bcmgr.getMaxRef(cnum, Cpos);
		String redirectURL = "BoardRead.jsp";
        
        redirectURL += "?num=" + cnum;
        // 지정된 URL로 리다이렉트
        response.sendRedirect(redirectURL);
	}

}
