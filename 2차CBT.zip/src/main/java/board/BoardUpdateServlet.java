package board;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import project.BoardBean;
import project.BoardMgr;

/**
 * Servlet implementation class BoardUpdateServlet
 */
@WebServlet("/board/BoardUpdate")
public class BoardUpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
	      BoardBean bean = (BoardBean) session.getAttribute("bean");
	      MultipartRequest multi = new MultipartRequest(request,
	    		  BoardMgr.SAVEFOLDER,
	    		  BoardMgr.MAXSIZE,
	    		  BoardMgr.ENCODING,
	            new DefaultFileRenamePolicy());
	      BoardMgr mgr = new BoardMgr();
	         mgr.updateBoard(multi);
	         String nowPage = multi.getParameter("nowPage");
	         String numPerPage = multi.getParameter("numPerPage");
	         response.sendRedirect("Board.jsp?nowPage="+nowPage
	               +"&numPerPage="+numPerPage
	               +"&num="+bean.getBoard_num());
	}

}
