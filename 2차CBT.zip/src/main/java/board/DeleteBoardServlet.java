package board;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import project.BoardMgr;
import project.UtilMgr;

/**
 * Servlet implementation class DeleteBoardServlet
 */
@WebServlet("/board/deleteboardpost")
public class DeleteBoardServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		BoardMgr mgr = new BoardMgr();
		int board_num = UtilMgr.parseInt(request, "num");
		System.out.print(board_num);
		mgr.deleteboard(board_num);
		String redirectURL = "Board.jsp";
        //지정된 URL로 리다이렉트
        response.sendRedirect(redirectURL);

	}

}
