package table;

public class TableListBean {
	private int tablelist_num;
	private String tablelist_table;
	private String tablelist_name;
	private int tablelist_user_op;
	private int tablelist_pay_op;
	private int tablelist_likey_op;
	private int tablelist_fileupload_op;
	private int tablelist_comment_op;
	
	
	
	public int getTablelist_num() {
		return tablelist_num;
	}
	public void setTablelist_num(int tablelist_num) {
		this.tablelist_num = tablelist_num;
	}
	public String getTablelist_table() {
		return tablelist_table;
	}
	public void setTablelist_table(String tablelist_table) {
		this.tablelist_table = tablelist_table;
	}
	public String getTablelist_name() {
		return tablelist_name;
	}
	public void setTablelist_name(String tablelist_name) {
		this.tablelist_name = tablelist_name;
	}
	public int getTablelist_user_op() {
		return tablelist_user_op;
	}
	public void setTablelist_user_op(int tablelist_user_op) {
		this.tablelist_user_op = tablelist_user_op;
	}
	public int getTablelist_pay_op() {
		return tablelist_pay_op;
	}
	public void setTablelist_pay_op(int tablelist_pay_op) {
		this.tablelist_pay_op = tablelist_pay_op;
	}
	public int getTablelist_likey_op() {
		return tablelist_likey_op;
	}
	public void setTablelist_likey_op(int tablelist_likey_op) {
		this.tablelist_likey_op = tablelist_likey_op;
	}
	public int getTablelist_fileupload_op() {
		return tablelist_fileupload_op;
	}
	public void setTablelist_fileupload_op(int tablelist_uploadfile_op) {
		this.tablelist_fileupload_op = tablelist_uploadfile_op;
	}
	public int getTablelist_comment_op() {
		return tablelist_comment_op;
	}
	public void setTablelist_comment_op(int tablelist_comment_op) {
		this.tablelist_comment_op = tablelist_comment_op;
	}
	
	
	
	
}
