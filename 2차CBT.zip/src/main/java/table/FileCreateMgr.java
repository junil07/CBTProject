package table;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.DirectoryNotEmptyException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;


public class FileCreateMgr {
	
	
	
	//자바 폴더 생성
	public void javafolderCreate(String COL) {			
		String path = "C:\\jsp\\TestProject2\\src\\main\\java\\"+COL;
		File Folder = new File(path);

		// 해당 디렉토리가 없을경우 디렉토리를 생성합니다.
		if (!Folder.exists()) {
			try{
			    Folder.mkdir(); //폴더 생성합니다.
			    System.out.println("폴더가 생성되었습니다.");
		        } 
		        catch(Exception e){
			    e.getStackTrace();
			}        
	         }else {
			System.out.println("이미 폴더가 생성되어 있습니다.");
		}
	    
	}
	
	
	
	//jsp 폴더 생성
		public void jspfolderCreate(String COL) {			
			String path = "C:\\jsp\\TestProject2\\src\\main\\webapp\\"+COL;
			File Folder = new File(path);

			// 해당 디렉토리가 없을경우 디렉토리를 생성합니다.
			if (!Folder.exists()) {
				try{
				    Folder.mkdir(); //폴더 생성합니다.
				    System.out.println("폴더가 생성되었습니다.");
			        } 
			        catch(Exception e){
				    e.getStackTrace();
				}        
		         }else {
				System.out.println("이미 폴더가 생성되어 있습니다.");
			}
		    
		}
	
    
	//기본 mgr
	public void mgrCreate(String COL) {
		String text = "";
        try {
        	Create mgrCreate = new Create();
        	text = mgrCreate.head(COL);
        	text += mgrCreate.basicName(COL);
        	text += mgrCreate.empty();
        	text += mgrCreate.allcolList(COL);
        	text += mgrCreate.empty();
        	text += mgrCreate.colList(COL);
        	text += mgrCreate.empty();
        	text += mgrCreate.totalCount(COL);
        	text += mgrCreate.empty();
        	text += mgrCreate.getUserName(COL);
        	text += mgrCreate.empty();
        	text += mgrCreate.getList(COL);
        	text += mgrCreate.empty();
        	text += mgrCreate.getUserGrade(COL);
        	text += mgrCreate.empty();
        	text += mgrCreate.insertcol(COL);
        	text += mgrCreate.empty();
        	text += mgrCreate.getMaxNum(COL);
        	text += mgrCreate.empty();
        	text += mgrCreate.getFile(COL);  
        	text += mgrCreate.empty();
        	text += mgrCreate.deletecol(COL); 
        	text += mgrCreate.empty();
        	text += mgrCreate.upCount(COL);     
        	text += mgrCreate.empty();
        	text += mgrCreate.postupdateAll(COL);
        	text += mgrCreate.end();
        	
        	System.out.println(COL);
            // 파일 객체 생성
            File file = new File("C:\\jsp\\TestProject2\\src\\main\\java\\"+COL+"\\"+COL+"Mgr.java");

            // 파일 존재 여부 체크 및 생성
            if (!file.exists()) {
                if (file.createNewFile()) {
                    System.out.println("파일 생성 성공");
                } else {
                    System.out.println("파일 생성 실패");
                    return; // 파일 생성에 실패했으므로 종료
                }
            }

            // BufferedWriter를 사용해서 File에 write할 수 있는 BufferedWriter 생성
            FileWriter fw = new FileWriter(file);
            BufferedWriter writer = new BufferedWriter(fw);

            // 파일에 쓰기
            writer.write(text);

            // BufferedWriter close
            writer.close();
            fw.close();

            

            System.out.println("파일에 쓰기 완료");

        } catch (IOException e) {
            // 예외를 출력하는 대신 로깅 시스템을 사용하여 예외를 기록하는 것이 좋습니다.
            e.printStackTrace();
        }
    }
	
	
	//댓글 mgr
	public void commentmgrCreate(String COL) {
			String text = "";
	        try {
	        	Create mgrCreate = new Create();
	        	text = mgrCreate.head(COL);
	        	text += mgrCreate.commentName(COL);
	        	text += mgrCreate.empty();
	        	text += mgrCreate.getthisName(COL);
	        	text += mgrCreate.empty();
	        	text += mgrCreate.getCountComment(COL);
	        	text += mgrCreate.empty();
	        	text += mgrCreate.getCommentList(COL);
	        	text += mgrCreate.empty();
	        	text += mgrCreate.underComment(COL);
	        	text += mgrCreate.empty();
	        	text += mgrCreate.getMaxPos(COL);
	        	text += mgrCreate.empty();
	        	text += mgrCreate.getMaxRef(COL);
	        	text += mgrCreate.empty();
	        	text += mgrCreate.getMaxdepth(COL);
	        	text += mgrCreate.empty();
	        	text += mgrCreate.deleteComment(COL);
	        	text += mgrCreate.empty();
	        	text += mgrCreate.insertComment(COL);
	        	text += mgrCreate.end();
	        	
	        	System.out.println(COL);
	            // 파일 객체 생성
	            File file = new File("C:\\jsp\\TestProject2\\src\\main\\java\\"+COL+"\\"+COL+"_commentMgr.java");

	            // 파일 존재 여부 체크 및 생성
	            if (!file.exists()) {
	                if (file.createNewFile()) {
	                    System.out.println("파일 생성 성공");
	                } else {
	                    System.out.println("파일 생성 실패");
	                    return; // 파일 생성에 실패했으므로 종료
	                }
	            }

	            // BufferedWriter를 사용해서 File에 write할 수 있는 BufferedWriter 생성
	            FileWriter fw = new FileWriter(file);
	            BufferedWriter writer = new BufferedWriter(fw);

	            // 파일에 쓰기
	            writer.write(text);

	            // BufferedWriter close
	            writer.close();
	            fw.close();

	            

	            System.out.println("파일에 쓰기 완료");

	        } catch (IOException e) {
	            // 예외를 출력하는 대신 로깅 시스템을 사용하여 예외를 기록하는 것이 좋습니다.
	            e.printStackTrace();
	        }
	    }
	
	
	//파일 빈즈
	public void filebeanCreate(String COL) {
		String text = "";
        try {
        	Create beanCreate = new Create();
        	text = beanCreate.fileuploadbean(COL);
        	
        	System.out.println(COL);
            // 파일 객체 생성
            File file = new File("C:\\jsp\\TestProject2\\src\\main\\java\\"+COL+"\\"+COL+"_fileuploadBean.java");

            // 파일 존재 여부 체크 및 생성
            if (!file.exists()) {
                if (file.createNewFile()) {
                    System.out.println("파일빈즈파일 생성 성공");
                } else {
                    System.out.println("파일빈즈파일 생성 실패");
                    return; // 파일 생성에 실패했으므로 종료
                }
            }

            // BufferedWriter를 사용해서 File에 write할 수 있는 BufferedWriter 생성
            FileWriter fw = new FileWriter(file);
            BufferedWriter writer = new BufferedWriter(fw);

            // 파일에 쓰기
            writer.write(text);

            // BufferedWriter close
            writer.close();
            fw.close();

            

            System.out.println("파일 빈즈파일 쓰기 완료");

        } catch (IOException e) {
            // 예외를 출력하는 대신 로깅 시스템을 사용하여 예외를 기록하는 것이 좋습니다.
            e.printStackTrace();
        }
    }
	
	
	//댓글 빈즈
	public void commentbeanCreate(String COL) {
			String text = "";
	        try {
	        	Create beanCreate = new Create();
	        	text = beanCreate.commentbean(COL);
	        	
	        	System.out.println(COL);
	            // 파일 객체 생성
	            File file = new File("C:\\jsp\\TestProject2\\src\\main\\java\\"+COL+"\\"+COL+"_commentBean.java");

	            // 파일 존재 여부 체크 및 생성
	            if (!file.exists()) {
	                if (file.createNewFile()) {
	                    System.out.println("파일빈즈파일 생성 성공");
	                } else {
	                    System.out.println("파일빈즈파일 생성 실패");
	                    return; // 파일 생성에 실패했으므로 종료
	                }
	            }

	            // BufferedWriter를 사용해서 File에 write할 수 있는 BufferedWriter 생성
	            FileWriter fw = new FileWriter(file);
	            BufferedWriter writer = new BufferedWriter(fw);

	            // 파일에 쓰기
	            writer.write(text);

	            // BufferedWriter close
	            writer.close();
	            fw.close();

	            

	            System.out.println("파일 빈즈파일 쓰기 완료");

	        } catch (IOException e) {
	            // 예외를 출력하는 대신 로깅 시스템을 사용하여 예외를 기록하는 것이 좋습니다.
	            e.printStackTrace();
	        }
	    }
	
	
	//기본 빈
	public void beanCreate(String COL) {
		String text = "";
        try {
        	Create beanCreate = new Create();
        	text = beanCreate.colbean(COL);
        	
        	System.out.println(COL);
            // 파일 객체 생성
            File file = new File("C:\\jsp\\TestProject2\\src\\main\\java\\"+COL+"\\"+COL+"Bean.java");

            // 파일 존재 여부 체크 및 생성
            if (!file.exists()) {
                if (file.createNewFile()) {
                    System.out.println("빈즈파일 생성 성공");
                } else {
                    System.out.println("빈즈파일 생성 실패");
                    return; // 파일 생성에 실패했으므로 종료
                }
            }

            // BufferedWriter를 사용해서 File에 write할 수 있는 BufferedWriter 생성
            FileWriter fw = new FileWriter(file);
            BufferedWriter writer = new BufferedWriter(fw);

            // 파일에 쓰기
            writer.write(text);

            // BufferedWriter close
            writer.close();
            fw.close();

            

            System.out.println("빈즈파일 쓰기 완료");

        } catch (IOException e) {
            // 예외를 출력하는 대신 로깅 시스템을 사용하여 예외를 기록하는 것이 좋습니다.
            e.printStackTrace();
        }
    }
	
	
	//작성 서블랫
	public void postServlet(String COL) {
		String text = "";
        try {
        	Create mgrCreate = new Create();
        	text = mgrCreate.postServlet(COL);
        	
        	System.out.println(COL);
            // 파일 객체 생성
            File file = new File("C:\\jsp\\TestProject2\\src\\main\\java\\"+COL+"\\"+COL+"PostServlet.java");

            // 파일 존재 여부 체크 및 생성
            if (!file.exists()) {
                if (file.createNewFile()) {
                    System.out.println("파일 생성 성공");
                } else {
                    System.out.println("파일 생성 실패");
                    return; // 파일 생성에 실패했으므로 종료
                }
            }

            // BufferedWriter를 사용해서 File에 write할 수 있는 BufferedWriter 생성
            FileWriter fw = new FileWriter(file);
            BufferedWriter writer = new BufferedWriter(fw);

            // 파일에 쓰기
            writer.write(text);

            // BufferedWriter close
            writer.close();
            fw.close();

            

            System.out.println("파일에 쓰기 완료");

        } catch (IOException e) {
            // 예외를 출력하는 대신 로깅 시스템을 사용하여 예외를 기록하는 것이 좋습니다.
            e.printStackTrace();
        }
    }
	
	
	//업데이트 서블랫
	public void updateServlet(String COL) {
		String text = "";
        try {
        	Create mgrCreate = new Create();
        	text = mgrCreate.updateServlet(COL);
        	
        	System.out.println(COL);
            // 파일 객체 생성
            File file = new File("C:\\jsp\\TestProject2\\src\\main\\java\\"+COL+"\\"+COL+"UpdateServlet.java");

            // 파일 존재 여부 체크 및 생성
            if (!file.exists()) {
                if (file.createNewFile()) {
                    System.out.println("파일 생성 성공");
                } else {
                    System.out.println("파일 생성 실패");
                    return; // 파일 생성에 실패했으므로 종료
                }
            }

            // BufferedWriter를 사용해서 File에 write할 수 있는 BufferedWriter 생성
            FileWriter fw = new FileWriter(file);
            BufferedWriter writer = new BufferedWriter(fw);

            // 파일에 쓰기
            writer.write(text);

            // BufferedWriter close
            writer.close();
            fw.close();

            

            System.out.println("파일에 쓰기 완료");

        } catch (IOException e) {
            // 예외를 출력하는 대신 로깅 시스템을 사용하여 예외를 기록하는 것이 좋습니다.
            e.printStackTrace();
        }
    }

	
	//삭제 서블랫
		public void deleteServlet(String COL) {
			String text = "";
	        try {
	        	Create mgrCreate = new Create();
	        	text = mgrCreate.deleteServlet(COL);
	        	
	        	System.out.println(COL);
	            // 파일 객체 생성
	            File file = new File("C:\\jsp\\TestProject2\\src\\main\\java\\"+COL+"\\Delete"+COL+"Servlet.java");

	            // 파일 존재 여부 체크 및 생성
	            if (!file.exists()) {
	                if (file.createNewFile()) {
	                    System.out.println("파일 생성 성공");
	                } else {
	                    System.out.println("파일 생성 실패");
	                    return; // 파일 생성에 실패했으므로 종료
	                }
	            }

	            // BufferedWriter를 사용해서 File에 write할 수 있는 BufferedWriter 생성
	            FileWriter fw = new FileWriter(file);
	            BufferedWriter writer = new BufferedWriter(fw);

	            // 파일에 쓰기
	            writer.write(text);

	            // BufferedWriter close
	            writer.close();
	            fw.close();

	            

	            System.out.println("파일에 쓰기 완료");

	        } catch (IOException e) {
	            // 예외를 출력하는 대신 로깅 시스템을 사용하여 예외를 기록하는 것이 좋습니다.
	            e.printStackTrace();
	        }
	    }
		
		//댓글 삭제 서블랫
		public void delcommentServlet(String COL) {
			String text = "";
	        try {
	        	Create mgrCreate = new Create();
	        	text = mgrCreate.delcommentServlet(COL);
	        	
	        	System.out.println(COL);
	            // 파일 객체 생성
	            File file = new File("C:\\jsp\\TestProject2\\src\\main\\java\\"+COL+"\\DeleteServletComment.java");

	            // 파일 존재 여부 체크 및 생성
	            if (!file.exists()) {
	                if (file.createNewFile()) {
	                    System.out.println("파일 생성 성공");
	                } else {
	                    System.out.println("파일 생성 실패");
	                    return; // 파일 생성에 실패했으므로 종료
	                }
	            }

	            // BufferedWriter를 사용해서 File에 write할 수 있는 BufferedWriter 생성
	            FileWriter fw = new FileWriter(file);
	            BufferedWriter writer = new BufferedWriter(fw);

	            // 파일에 쓰기
	            writer.write(text);

	            // BufferedWriter close
	            writer.close();
	            fw.close();

	            

	            System.out.println("파일에 쓰기 완료");

	        } catch (IOException e) {
	            // 예외를 출력하는 대신 로깅 시스템을 사용하여 예외를 기록하는 것이 좋습니다.
	            e.printStackTrace();
	        }
	    }
	
	
	//대댓글 서블랫
	public void recommentServlet(String COL) {
		String text = "";
        try {
        	Create mgrCreate = new Create();
        	text = mgrCreate.recommentServlet(COL);
        	
        	System.out.println(COL);
            // 파일 객체 생성
            File file = new File("C:\\jsp\\TestProject2\\src\\main\\java\\"+COL+"\\insertUnderCommetServlet.java");

            // 파일 존재 여부 체크 및 생성
            if (!file.exists()) {
                if (file.createNewFile()) {
                    System.out.println("파일 생성 성공");
                } else {
                    System.out.println("파일 생성 실패");
                    return; // 파일 생성에 실패했으므로 종료
                }
            }

            // BufferedWriter를 사용해서 File에 write할 수 있는 BufferedWriter 생성
            FileWriter fw = new FileWriter(file);
            BufferedWriter writer = new BufferedWriter(fw);

            // 파일에 쓰기
            writer.write(text);

            // BufferedWriter close
            writer.close();
            fw.close();

            

            System.out.println("파일에 쓰기 완료");

        } catch (IOException e) {
            // 예외를 출력하는 대신 로깅 시스템을 사용하여 예외를 기록하는 것이 좋습니다.
            e.printStackTrace();
        }
    }

	
	//기본 jsp
		public void basicJsp(String COL) {
			String text = "";
	        try {
	        	Create mgrCreate = new Create();
	        	text = mgrCreate.basicJsp(COL);
	        	
	        	System.out.println(COL);
	            // 파일 객체 생성
	            File file = new File("C:\\jsp\\TestProject2\\src\\main\\webapp\\"+COL+"\\"+COL+".jsp");

	            // 파일 존재 여부 체크 및 생성
	            if (!file.exists()) {
	                if (file.createNewFile()) {
	                    System.out.println("파일 생성 성공");
	                } else {
	                    System.out.println("파일 생성 실패");
	                    return; // 파일 생성에 실패했으므로 종료
	                }
	            }

	            // BufferedWriter를 사용해서 File에 write할 수 있는 BufferedWriter 생성
	            FileWriter fw = new FileWriter(file);
	            BufferedWriter writer = new BufferedWriter(fw);

	            // 파일에 쓰기
	            writer.write(text);

	            // BufferedWriter close
	            writer.close();
	            fw.close();

	            

	            System.out.println("파일에 쓰기 완료");

	        } catch (IOException e) {
	            // 예외를 출력하는 대신 로깅 시스템을 사용하여 예외를 기록하는 것이 좋습니다.
	            e.printStackTrace();
	        }
	    }
		
		
	//update jsp
	public void updateJsp(String COL) {
		String text = "";
        try {
        	Create mgrCreate = new Create();
        	text = mgrCreate.updateJsp(COL);
        	
        	System.out.println(COL);
            // 파일 객체 생성
            File file = new File("C:\\jsp\\TestProject2\\src\\main\\webapp\\"+COL+"\\"+COL+"Update.jsp");

            // 파일 존재 여부 체크 및 생성
            if (!file.exists()) {
                if (file.createNewFile()) {
                    System.out.println("파일 생성 성공");
                } else {
                    System.out.println("파일 생성 실패");
                    return; // 파일 생성에 실패했으므로 종료
                }
            }

            // BufferedWriter를 사용해서 File에 write할 수 있는 BufferedWriter 생성
            FileWriter fw = new FileWriter(file);
            BufferedWriter writer = new BufferedWriter(fw);

            // 파일에 쓰기
            writer.write(text);

            // BufferedWriter close
            writer.close();
            fw.close();

            

            System.out.println("파일에 쓰기 완료");

        } catch (IOException e) {
            // 예외를 출력하는 대신 로깅 시스템을 사용하여 예외를 기록하는 것이 좋습니다.
            e.printStackTrace();
        }
		    }

		
	//post jsp
	public void postJsp(String COL) {
		String text = "";
        try {
        	Create mgrCreate = new Create();
        	text = mgrCreate.postJsp(COL);
        	
        	System.out.println(COL);
            // 파일 객체 생성
            File file = new File("C:\\jsp\\TestProject2\\src\\main\\webapp\\"+COL+"\\"+COL+"Post.jsp");

            // 파일 존재 여부 체크 및 생성
            if (!file.exists()) {
                if (file.createNewFile()) {
                    System.out.println("파일 생성 성공");
                } else {
                    System.out.println("파일 생성 실패");
                    return; // 파일 생성에 실패했으므로 종료
                }
            }

            // BufferedWriter를 사용해서 File에 write할 수 있는 BufferedWriter 생성
            FileWriter fw = new FileWriter(file);
            BufferedWriter writer = new BufferedWriter(fw);

            // 파일에 쓰기
            writer.write(text);

            // BufferedWriter close
            writer.close();
            fw.close();

            

            System.out.println("파일에 쓰기 완료");

        } catch (IOException e) {
            // 예외를 출력하는 대신 로깅 시스템을 사용하여 예외를 기록하는 것이 좋습니다.
            e.printStackTrace();
        }
    }
		
	
	//read jsp
	public void readJsp(String COL) {
		String text = "";
        try {
        	Create mgrCreate = new Create();
        	text = mgrCreate.readJsp(COL);
        	
        	System.out.println(COL);
            // 파일 객체 생성
            File file = new File("C:\\jsp\\TestProject2\\src\\main\\webapp\\"+COL+"\\"+COL+"Read.jsp");

            // 파일 존재 여부 체크 및 생성
            if (!file.exists()) {
                if (file.createNewFile()) {
                    System.out.println("파일 생성 성공");
                } else {
                    System.out.println("파일 생성 실패");
                    return; // 파일 생성에 실패했으므로 종료
                }
            }

            // BufferedWriter를 사용해서 File에 write할 수 있는 BufferedWriter 생성
            FileWriter fw = new FileWriter(file);
            BufferedWriter writer = new BufferedWriter(fw);

            // 파일에 쓰기
            writer.write(text);

            // BufferedWriter close
            writer.close();
            fw.close();

            

            System.out.println("파일에 쓰기 완료");

        } catch (IOException e) {
            // 예외를 출력하는 대신 로깅 시스템을 사용하여 예외를 기록하는 것이 좋습니다.
            e.printStackTrace();
        }
    }
	
	
	
	//download jsp
	public void downloadJsp(String COL) {
		String text = "";
        try {
        	Create mgrCreate = new Create();
        	text = mgrCreate.downloadJsp(COL);
        	
        	System.out.println(COL);
            // 파일 객체 생성
            File file = new File("C:\\jsp\\TestProject2\\src\\main\\webapp\\"+COL+"\\"+COL+"Download.jsp");

            // 파일 존재 여부 체크 및 생성
            if (!file.exists()) {
                if (file.createNewFile()) {
                    System.out.println("파일 생성 성공");
                } else {
                    System.out.println("파일 생성 실패");
                    return; // 파일 생성에 실패했으므로 종료
                }
            }

            // BufferedWriter를 사용해서 File에 write할 수 있는 BufferedWriter 생성
            FileWriter fw = new FileWriter(file);
            BufferedWriter writer = new BufferedWriter(fw);

            // 파일에 쓰기
            writer.write(text);

            // BufferedWriter close
            writer.close();
            fw.close();

            

            System.out.println("파일에 쓰기 완료");

        } catch (IOException e) {
            // 예외를 출력하는 대신 로깅 시스템을 사용하여 예외를 기록하는 것이 좋습니다.
            e.printStackTrace();
        }
    }
		
		
		
	public void allCreate(String COL) {
		javafolderCreate(COL);
		jspfolderCreate(COL);
		mgrCreate(COL);
		commentmgrCreate(COL);
		beanCreate(COL);
		filebeanCreate(COL);
		commentbeanCreate(COL);
		postServlet(COL);
		updateServlet(COL);
		deleteServlet(COL);
		delcommentServlet(COL);
		recommentServlet(COL);
		basicJsp(COL);
		postJsp(COL);
		updateJsp(COL);
		readJsp(COL);
		downloadJsp(COL);
	}
	
	
	public void allDelete(String COL) {
		String[] fileList = {
			    "C:\\jsp\\TestProject2\\src\\main\\java\\"+COL+"\\"+COL+"Mgr.java",
			    "C:\\jsp\\TestProject2\\src\\main\\java\\"+COL+"\\"+COL+"_commentMgr.java",
			    "C:\\jsp\\TestProject2\\src\\main\\java\\"+COL+"\\"+COL+"_fileuploadBean.java",
			    "C:\\jsp\\TestProject2\\src\\main\\java\\"+COL+"\\"+COL+"_commentBean.java",
			    "C:\\jsp\\TestProject2\\src\\main\\java\\"+COL+"\\"+COL+"Bean.java",
			    "C:\\jsp\\TestProject2\\src\\main\\java\\"+COL+"\\"+COL+"PostServlet.java",
			    "C:\\jsp\\TestProject2\\src\\main\\java\\"+COL+"\\Delete"+COL+"Servlet.java",
			    "C:\\jsp\\TestProject2\\src\\main\\java\\"+COL+"\\DeleteServletComment.java",
			    "C:\\jsp\\TestProject2\\src\\main\\java\\"+COL+"\\insertUnderCommetServlet.java",
			    "C:\\jsp\\TestProject2\\src\\main\\java\\"+COL+"\\"+COL+"UpdateServlet.java",
			    "C:\\jsp\\TestProject2\\src\\main\\webapp\\"+COL+"\\"+COL+".jsp",
			    "C:\\jsp\\TestProject2\\src\\main\\webapp\\"+COL+"\\"+COL+"Post.jsp",
			    "C:\\jsp\\TestProject2\\src\\main\\webapp\\"+COL+"\\"+COL+"Read.jsp",
			    "C:\\jsp\\TestProject2\\src\\main\\webapp\\"+COL+"\\"+COL+"Download.jsp",
			    "C:\\jsp\\TestProject2\\src\\main\\webapp\\"+COL+"\\"+COL+"Update.jsp"
			};

			String[] folderList = {
			    "C:\\jsp\\TestProject2\\src\\main\\java\\"+COL,
			    "C:\\jsp\\TestProject2\\src\\main\\webapp\\"+COL
		};
		
		for (int i = 0; i<15; i++) {
			Path filePath = Paths.get(fileList[i]);  
			try {               
				Files.delete(filePath);                        
				                  
			} catch (NoSuchFileException e) {            
				System.out.println("삭제하려는 파일/디렉토리가 없습니다");        
			} catch (DirectoryNotEmptyException e) {            
				System.out.println("디렉토리가 비어있지 않습니다");        
			} catch (IOException e) {            
				e.printStackTrace();        
			}
		}
		
		for (int i = 0; i<2; i++) {
			Path directoryPath = Paths.get(folderList[i]);  
			try {               
				Files.delete(directoryPath);                                          
			} catch (NoSuchFileException e) {            
				System.out.println("삭제하려는 파일/디렉토리가 없습니다");        
			} catch (DirectoryNotEmptyException e) {            
				System.out.println("디렉토리가 비어있지 않습니다");        
			} catch (IOException e) {            
				e.printStackTrace();        
			}
		}

			
	}
	
	public static void main(String[] args) {
		
		FileCreateMgr mgr = new FileCreateMgr();
		mgr.allCreate("ehehe");
		//mgr.allUpdate("dont", "can");
		//mgr.allDelete("dont");
		
    }
    
    	
}
