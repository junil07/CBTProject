package project;

public class ExplanationBean {
	
	private int explanation_num, explanation_question_num, explanation_filesize;
	private String explanation_content, explanation_file,explanation_test_num;
	public int getExplanation_num() {
		return explanation_num;
	}
	public void setExplanation_num(int explanation_num) {
		this.explanation_num = explanation_num;
	}
	public String getExplanation_test_num() {
		return explanation_test_num;
	}
	public void setExplanation_test_num(String explanation_test_num) {
		this.explanation_test_num = explanation_test_num;
	}
	public int getExplanation_question_num() {
		return explanation_question_num;
	}
	public void setExplanation_question_num(int explanation_question_num) {
		this.explanation_question_num = explanation_question_num;
	}
	public int getExplanation_filesize() {
		return explanation_filesize;
	}
	public void setExplanation_filesize(int explanation_filesize) {
		this.explanation_filesize = explanation_filesize;
	}
	public String getExplanation_content() {
		return explanation_content;
	}
	public void setExplanation_content(String explanation_content) {
		this.explanation_content = explanation_content;
	}
	public String getExplanation_file() {
		return explanation_file;
	}
	public void setExplanation_file(String explanation_file) {
		this.explanation_file = explanation_file;
	}
	
	
	
}
