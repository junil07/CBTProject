package project;

public class Paypost_likeyBean {
	private int paypost_likey_num;
	private int likey_paypost_num;
	private String paypost_likey_user_id;
	
	public int getPaypost_likey_num() {
		return paypost_likey_num;
	}
	public void setPaypost_likey_num(int paypost_likey_num) {
		this.paypost_likey_num = paypost_likey_num;
	}
	public int getLikey_paypost_num() {
		return likey_paypost_num;
	}
	public void setLikey_paypost_num(int likey_paypost_num) {
		this.likey_paypost_num = likey_paypost_num;
	}
	public String getPaypost_likey_user_id() {
		return paypost_likey_user_id;
	}
	public void setPaypost_likey_user_id(String paypost_likey_user_id) {
		this.paypost_likey_user_id = paypost_likey_user_id;
	}
}
