package project;

public class ManagerBean {
	
	private String manage_id, manage_pwd, manage_name, manage_phone;

	public String getManage_id() {
		return manage_id;
	}

	public void setManage_id(String manage_id) {
		this.manage_id = manage_id;
	}

	public String getManage_pwd() {
		return manage_pwd;
	}

	public void setManage_pwd(String manage_pwd) {
		this.manage_pwd = manage_pwd;
	}

	public String getManage_name() {
		return manage_name;
	}

	public void setManage_name(String manage_name) {
		this.manage_name = manage_name;
	}

	public String getManage_phone() {
		return manage_phone;
	}

	public void setManage_phone(String manage_phone) {
		this.manage_phone = manage_phone;
	}
	
	
	
}
