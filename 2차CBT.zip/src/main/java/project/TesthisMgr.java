package project;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

public class TesthisMgr {
	
	private DBConnectionMgr pool;
	
	public TesthisMgr() {
		pool = DBConnectionMgr.getInstance();
	}
	
	public void testHisInsert(String userId, String title,String year, String sec,String userCorrect) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = null;
		try {
			con = pool.getConnection();
			sql = "insert into testhis(testhis_user_id,testhis_test_title,testhis_test_year,testhis_test_sec,testhis_ins_time,testhis_user_correct) "
					+ "value(?,?,?,?,now(),?)";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, userId);
			pstmt.setString(2, title);
			pstmt.setString(3, year);
			pstmt.setString(4, sec);
			pstmt.setString(5, userCorrect);
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt);
		}
	}
	
	public boolean testhisDupli(String userId,String title,String testYear,String testSec,String userCorrect) {
    	Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		boolean flag = false;
		try {
			con = pool.getConnection();
			sql = "select * from testhis where testhis_user_id=? and testhis_test_title=? and testhis_test_year=? and testhis_test_sec=? and testhis_user_correct=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1,userId);
			pstmt.setString(2,title);
			pstmt.setString(3,testYear);
			pstmt.setString(4,testSec);
			pstmt.setString(5,userCorrect);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				flag = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return flag;
    }
	
	public int getTotalCount(String keyField,String keyWord) {
    	Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		int totalCount = 0;
		try {
			con = pool.getConnection();
			if ( keyWord.trim().equals("") || keyWord == null ) {
				sql = "SELECT COUNT(*) FROM testhis";
				pstmt = con.prepareStatement(sql);
			} else {
				sql = "SELECT COUNT(*) FROM testhis "
						+ "WHERE " + keyField + " LIKE ?";
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, "%" + keyWord + "%");
			}
			
			rs = pstmt.executeQuery();
			if ( rs.next() ) totalCount = rs.getInt(1);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return totalCount;
    }
    
    public Vector<TesthisBean> getWrongList(String keyField, String keyWord, int start, int cnt ,String userId){
    	Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<TesthisBean> vlist = new Vector<TesthisBean>();
		try {
			con = pool.getConnection();
			
			if ( keyWord.trim().equals("") || keyWord == null ) {
				sql = "SELECT * FROM testhis where testhis_user_id=? ORDER BY testhis_num DESC LIMIT ?, ?";
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, userId);
				pstmt.setInt(2, start);
				pstmt.setInt(3, cnt);
			} else {
				sql = "SELECT * FROM testhis WHERE " + keyField + " LIKE ? and testhis_user_id=? ORDER BY testhis_num DESC LIMIT ?, ?";
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, "%" + keyWord + "%");
				pstmt.setString(2, userId);
				pstmt.setInt(3, start);
				pstmt.setInt(4, cnt);
			}
			
			rs = pstmt.executeQuery();
			while ( rs.next() ) {
				TesthisBean bean = new TesthisBean();
				bean.setTesthis_num(rs.getInt("testhis_num"));
				bean.setTesthis_user_id(rs.getString("testhis_user_id"));
				bean.setTesthis_test_title(rs.getString("testhis_test_title"));
				bean.setTesthis_test_year(rs.getString("testhis_test_year"));
				bean.setTesthis_test_sec(rs.getString("testhis_test_sec"));
				bean.setTesthis_test_time(rs.getString("testhis_ins_time"));
				bean.setTesthis_user_correct(rs.getString("testhis_user_correct"));
				vlist.addElement(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
    }
    
    public int gettestHisCount(String userId) {
    	Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		int count=0;
		try {
			con = pool.getConnection();
			sql = "select count(*) from testhis where testhis_user_id=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, userId);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				count = rs.getInt(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return count;
    }
}
