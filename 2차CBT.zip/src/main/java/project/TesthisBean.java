package project;

public class TesthisBean {
	private int testhis_num;
	private String testhis_user_id;
	private String testhis_test_title;
	private String testhis_test_year;
	private String testhis_test_sec;
	private String testhis_test_time;
	private String testhis_user_correct;
	public int getTesthis_num() {
		return testhis_num;
	}
	public void setTesthis_num(int testhis_num) {
		this.testhis_num = testhis_num;
	}
	public String getTesthis_user_id() {
		return testhis_user_id;
	}
	public void setTesthis_user_id(String testhis_user_id) {
		this.testhis_user_id = testhis_user_id;
	}
	public String getTesthis_test_title() {
		return testhis_test_title;
	}
	public void setTesthis_test_title(String testhis_test_title) {
		this.testhis_test_title = testhis_test_title;
	}
	public String getTesthis_test_year() {
		return testhis_test_year;
	}
	public void setTesthis_test_year(String testhis_test_year) {
		this.testhis_test_year = testhis_test_year;
	}
	public String getTesthis_test_sec() {
		return testhis_test_sec;
	}
	public void setTesthis_test_sec(String testhis_test_sec) {
		this.testhis_test_sec = testhis_test_sec;
	}
	public String getTesthis_test_time() {
		return testhis_test_time;
	}
	public void setTesthis_test_time(String testhis_test_time) {
		this.testhis_test_time = testhis_test_time;
	}
	public String getTesthis_user_correct() {
		return testhis_user_correct;
	}
	public void setTesthis_user_correct(String testhis_user_correct) {
		this.testhis_user_correct = testhis_user_correct;
	}
	
}
