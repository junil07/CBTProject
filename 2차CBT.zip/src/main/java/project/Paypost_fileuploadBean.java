package project;

public class Paypost_fileuploadBean {
   private String paypost_fileupload_server_name;
   private int fileupload_paypost_num;
   private String paypost_fileupload_name;
   private String paypost_fileupload_extension;
   private int paypost_fileupload_size;
   
   
   public String getPaypost_fileupload_server_name() {
      return paypost_fileupload_server_name;
   }
   public void setPaypost_fileupload_server_name(String paypost_fileupload_server_name) {
      this.paypost_fileupload_server_name = paypost_fileupload_server_name;
   }
   public int getFileupload_paypost_num() {
      return fileupload_paypost_num;
   }
   public void setFileupload_paypost_num(int fileupload_paypost_num) {
      this.fileupload_paypost_num = fileupload_paypost_num;
   }
   public String getPaypost_fileupload_name() {
      return paypost_fileupload_name;
   }
   public void setPaypost_fileupload_name(String paypost_fileupload_name) {
      this.paypost_fileupload_name = paypost_fileupload_name;
   }
   public String getPaypost_fileupload_extension() {
      return paypost_fileupload_extension;
   }
   public void setPaypost_fileupload_extension(String paypost_fileupload_extension) {
      this.paypost_fileupload_extension = paypost_fileupload_extension;
   }
   public int getPaypost_fileupload_size() {
      return paypost_fileupload_size;
   }
   public void setPaypost_fileupload_size(int paypost_fileupload_size) {
      this.paypost_fileupload_size = paypost_fileupload_size;
   }
   
   
   
}
