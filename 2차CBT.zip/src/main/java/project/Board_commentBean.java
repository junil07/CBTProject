package project;

public class Board_commentBean {
	private int board_comment_num;
	private int comment_board_num;
	private String board_comment_content;
	private int board_comment_reply_pos;
	private int board_comment_reply_ref;
	private int board_comment_reply_depth;
	private String board_comment_user_id;
	private String board_comment_date;
	
	public int getBoard_comment_num() {
		return board_comment_num;
	}
	public void setBoard_comment_num(int board_comment_num) {
		this.board_comment_num = board_comment_num;
	}
	public int getComment_board_num() {
		return comment_board_num;
	}
	public void setComment_board_num(int comment_board_num) {
		this.comment_board_num = comment_board_num;
	}
	public String getBoard_comment_content() {
		return board_comment_content;
	}
	public void setBoard_comment_content(String board_comment_content) {
		this.board_comment_content = board_comment_content;
	}
	public int getBoard_comment_reply_pos() {
		return board_comment_reply_pos;
	}
	public void setBoard_comment_reply_pos(int board_comment_reply_pos) {
		this.board_comment_reply_pos = board_comment_reply_pos;
	}
	public int getBoard_comment_reply_ref() {
		return board_comment_reply_ref;
	}
	public void setBoard_comment_reply_ref(int board_comment_reply_ref) {
		this.board_comment_reply_ref = board_comment_reply_ref;
	}
	public int getBoard_comment_reply_depth() {
		return board_comment_reply_depth;
	}
	public void setBoard_comment_reply_depth(int board_comment_reply_depth) {
		this.board_comment_reply_depth = board_comment_reply_depth;
	}
	public String getBoard_comment_user_id() {
		return board_comment_user_id;
	}
	public void setBoard_comment_user_id(String board_comment_user_id) {
		this.board_comment_user_id = board_comment_user_id;
	}
	public String getBoard_comment_date() {
		return board_comment_date;
	}
	public void setBoard_comment_date(String board_comment_date) {
		this.board_comment_date = board_comment_date;
	}
	
	
}
