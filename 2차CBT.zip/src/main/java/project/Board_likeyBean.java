package project;

public class Board_likeyBean {
	private int board_likey_num;
	private int likey_board_num;
	private String board_likey_user_id;
	
	public int getBoard_likey_num() {
		return board_likey_num;
	}
	public void setBoard_likey_num(int board_likey_num) {
		this.board_likey_num = board_likey_num;
	}
	public int getLikey_board_num() {
		return likey_board_num;
	}
	public void setLikey_board_num(int likey_board_num) {
		this.likey_board_num = likey_board_num;
	}
	public String getBoard_likey_user_id() {
		return board_likey_user_id;
	}
	public void setBoard_likey_user_id(String board_likey_user_id) {
		this.board_likey_user_id = board_likey_user_id;
	}
	
	
}
