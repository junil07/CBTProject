package project;

public class WrongBean {
	private int wrong_num;
	private String wrong_user_id;
	private String wrong_test_title;
	private String wrong_test_year;
	private String wrong_test_sec;
	private String wrong_ins_time;
	private String wrong_question_num;
	
	public int getWrong_num() {
		return wrong_num;
	}
	public void setWrong_num(int wrong_num) {
		this.wrong_num = wrong_num;
	}
	public String getWrong_user_id() {
		return wrong_user_id;
	}
	public void setWrong_user_id(String wrong_user_id) {
		this.wrong_user_id = wrong_user_id;
	}
	public String getWrong_test_title() {
		return wrong_test_title;
	}
	public void setWrong_test_title(String wrong_test_title) {
		this.wrong_test_title = wrong_test_title;
	}
	public String getWrong_test_year() {
		return wrong_test_year;
	}
	public void setWrong_test_year(String wrong_test_year) {
		this.wrong_test_year = wrong_test_year;
	}
	public String getWrong_test_sec() {
		return wrong_test_sec;
	}
	public void setWrong_test_sec(String wrong_test_sec) {
		this.wrong_test_sec = wrong_test_sec;
	}
	public String getWrong_ins_time() {
		return wrong_ins_time;
	}
	public void setWrong_ins_time(String wrong_ins_time) {
		this.wrong_ins_time = wrong_ins_time;
	}
	public String getWrong_question_num() {
		return wrong_question_num;
	}
	public void setWrong_question_num(String wrong_question_num) {
		this.wrong_question_num = wrong_question_num;
	}
	
}
