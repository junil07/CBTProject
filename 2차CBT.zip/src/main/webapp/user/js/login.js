/**
 * 
 */
function test() {
	document.frm.action = "test3.jsp";
	document.frm.submit();
}