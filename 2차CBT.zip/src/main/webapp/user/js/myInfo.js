/**
 * 
 */

function showPopup() { 
	window.open("popup/pwdUpdate.jsp", "a", "width=740, height=450, left=750, top=300");
}

function namePopup() {
	window.open("popup/nameUpdate.jsp", "a", "width=650, height=390, left=750, top=300");
}

function phonePopup() {
	window.open("popup/phoneUpdate.jsp", "a", "width=650, height=400, left=750, top=300");
}

function emailPopup() {
	window.open("popup/emailUpdate.jsp", "a", "width=750, height=390, left=750, top=300");
}